using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class sphereMove : MonoBehaviour
{
    // Start is called before the first frame update
    float m_fSpeed = 12.0f;

    void Start()
    {

    }

    void Update()
    {
        float fHorizontal = Input.GetAxis("Horizontal");
        float fVertical = Input.GetAxis("Vertical");

        transform.Translate(Vector3.forward * Time.deltaTime * m_fSpeed * fHorizontal, Space.World);
        transform.Translate(Vector3.left * Time.deltaTime * m_fSpeed * fVertical, Space.World );
    }
}